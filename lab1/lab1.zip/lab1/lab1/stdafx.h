#pragma once
#include "Auxil.h"
#include "Fibonachi.h"
#include <iostream>
#include <locale>
#include <ctime>