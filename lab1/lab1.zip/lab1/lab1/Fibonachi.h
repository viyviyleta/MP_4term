#pragma once
long double fibonachi(int n);
